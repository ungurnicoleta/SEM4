package ro.ubb.hello3.client.ui;

import ro.ubb.hello3.common.HelloService;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

/**
 * author: radu
 */
public class ClientConsole {
    private HelloService helloService;

    public ClientConsole(HelloService helloService) {
        this.helloService = helloService;
    }

    public void runConsole() {
        sayHello();
        sayBye();
    }

    private void sayBye() {
        String name = "jane";

        Future<String> result = helloService.sayBye(name);

        try {
            //:(((((( blocking
            System.out.println("client - received result: " + result.get());
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }

    private void sayHello() {
        String name = "john";

        Future<String> result = helloService.sayHello(name);

        try {
            System.out.println("client - received result: " + result.get());
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }
}

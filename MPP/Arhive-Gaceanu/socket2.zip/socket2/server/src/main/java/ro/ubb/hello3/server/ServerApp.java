package ro.ubb.hello3.server;

import ro.ubb.hello3.common.HelloService;
import ro.ubb.hello3.common.Message;
import ro.ubb.hello3.server.service.HelloServiceImpl;
import ro.ubb.hello3.server.tcp.TcpServer;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * author: radu
 */
public class ServerApp {
    public static void main(String[] args) {
        ExecutorService executorService =
                Executors.newFixedThreadPool(
                        Runtime.getRuntime().availableProcessors());

        TcpServer tcpServer = new TcpServer(executorService,
                                            HelloService.SERVER_PORT);

        HelloService helloService = new HelloServiceImpl(executorService);


        tcpServer.addHandler(
                HelloService.SAY_HELLO, (request) -> {
                    String name = request.getBody();
                    Future<String> result =
                            helloService.sayHello(name);
                    try {
                        //compute response
//                        return new Message(Message.OK, result.get());
                        return getMessage(Message.OK, result.get());
                    } catch (InterruptedException | ExecutionException e) {
                        e.printStackTrace();
//                        return new Message(Message.ERROR, e.getMessage());
                        return getMessage(Message.ERROR, e.getMessage());
                    }
                });

        tcpServer.addHandler(
                HelloService.SAY_BYE, (request) -> {
                    String name = request.getBody();
                    Future<String> result =
                            helloService.sayBye(name);
                    try {
                        //compute response
                        return getMessage(Message.OK, result.get());
                    } catch (InterruptedException | ExecutionException e) {
                        e.printStackTrace();
                        return getMessage(Message.ERROR, e.getMessage());
                    }
                });

        tcpServer.startServer();

        System.out.println("server - bye");
    }

    private static Message getMessage(String header, String body) {
        return Message.builder()
                      .header(header)
                      .body(body)
                      .build();
    }


}

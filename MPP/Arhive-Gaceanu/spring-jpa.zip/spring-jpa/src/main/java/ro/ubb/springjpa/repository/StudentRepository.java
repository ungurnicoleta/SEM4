package ro.ubb.springjpa.repository;

import ro.ubb.springjpa.model.Student;

/**
 * author: radu
 */
public interface StudentRepository extends CatalogRepository<Student, Long> {
}

package ro.ubb.remoting.common;

import java.util.List;

/**
 * author: radu
 */
public interface StudentService {
    List<Student> findAll();
}

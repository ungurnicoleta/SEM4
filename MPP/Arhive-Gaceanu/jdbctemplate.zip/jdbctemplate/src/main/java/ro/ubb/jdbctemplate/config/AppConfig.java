package ro.ubb.jdbctemplate.config;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import ro.ubb.jdbctemplate.repository.StudentRepository;
import ro.ubb.jdbctemplate.repository.StudentRepositoryImpl;

import javax.sql.DataSource;

/**
 * author: radu
 */

@Configuration
public class AppConfig {

    @Bean
    StudentRepository studentRepository() {
        return new StudentRepositoryImpl();
    }

    @Bean
    JdbcOperations jdbcOperations() {
        JdbcTemplate jdbcTemplate = new JdbcTemplate();

        jdbcTemplate.setDataSource(dataSource());

        return jdbcTemplate;
    }

    @Bean
    DataSource dataSource() {
        BasicDataSource basicDataSource=new BasicDataSource();
        basicDataSource.setUrl("jdbc:postgresql://localhost:5432/jdbctemplate");
        basicDataSource.setUsername("postgres");
        basicDataSource.setPassword("admin");

        return basicDataSource;
    }
}

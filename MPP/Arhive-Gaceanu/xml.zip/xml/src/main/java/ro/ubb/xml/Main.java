package ro.ubb.xml;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * author: radu
 */
public class Main {
    public static void main(String[] args) {
        try {
            List<Book> books = loadData();
            books.forEach(System.out::println);

            Book book1 = new Book("web", "C++ Guide", "Mark Theadore", 2000,
                                  23);
            saveBook(book1);

            System.out.println("bye");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private static void saveBook(Book book1) throws Exception {
        Document document = DocumentBuilderFactory
                .newInstance()
                .newDocumentBuilder()
                .parse("data/bookstore.xml");
        Element root = document.getDocumentElement();

        Element bookElement = document.createElement("book");
        bookElement.setAttribute("category", book1.getCategory());
        root.appendChild(bookElement);

        appendChildWithText(document, bookElement, "title", book1.getTitle());
        appendChildWithText(document, bookElement, "author", book1.getAuthor());
        appendChildWithText(document, bookElement, "year",
                            String.valueOf(book1.getYear()));
        appendChildWithText(document, bookElement, "price",
                            String.valueOf(book1.getPrice()));

        Transformer transformer =
                TransformerFactory.newInstance().newTransformer();
        transformer.transform(new DOMSource(root),
                              new StreamResult(new FileOutputStream(
                                      "./data/result.xml")));
    }

    private static void appendChildWithText(Document document,
            Node parent, String tagName, String textContent) {
        Element element = document.createElement(tagName);
        element.setTextContent(textContent);
        parent.appendChild(element);
    }

    private static List<Book> loadData() throws Exception {
        List<Book> listOfBooks = new ArrayList<>();
        DocumentBuilderFactory documentBuilderFactory =
                DocumentBuilderFactory.newInstance();

        DocumentBuilder documentBuilder =
                documentBuilderFactory.newDocumentBuilder();
        Document document = documentBuilder.parse("data/bookstore.xml");
        Element root = document.getDocumentElement();

        NodeList nodes = root.getChildNodes();
        int len = nodes.getLength();
        for (int i = 0; i < len; i++) {
            Node bookNode = nodes.item(i);
            if (bookNode instanceof Element) {
                Book b = createBook((Element) bookNode);
                listOfBooks.add(b);
            }
        }
        return listOfBooks;
    }

    private static Book createBook(Element bookNode) {
        String category = bookNode.getAttribute("category");
        Book b = new Book();
        b.setCategory(category);

        b.setTitle(getTextFromTagName(bookNode, "title"));
        b.setAuthor(getTextFromTagName(bookNode, "author"));
        b.setYear(Integer.valueOf(getTextFromTagName(bookNode, "year")));
        b.setPrice(Float.valueOf(getTextFromTagName(bookNode, "price")));

        return b;
    }

    private static String getTextFromTagName(Element element, String tagName) {
        NodeList elements = element.getElementsByTagName(tagName);
        Node node = elements.item(0);
        return node.getTextContent();
    }


}

package ro.ubb.hello3.client.service;

import ro.ubb.hello3.client.tcp.TcpClient;
import ro.ubb.hello3.common.HelloService;
import ro.ubb.hello3.common.Message;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

/**
 * author: radu
 */
public class HelloServiceClientImpl implements HelloService {
    private ExecutorService executorService;
    private TcpClient tcpClient;

    public HelloServiceClientImpl(
            ExecutorService executorService, TcpClient tcpClient) {
        this.executorService = executorService;
        this.tcpClient = tcpClient;
    }

    @Override
    public Future<String> sayHello(String name) {
        return executorService.submit(() -> {
            Message request = new Message(HelloService.SAY_HELLO, name);

            Message response = tcpClient.sendAndReceive(request);

            String result = response.getBody();
            //todo: check header ok/error

            return result;
        });
    }
}

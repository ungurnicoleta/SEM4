package ro.ubb.hello3.client;

import ro.ubb.hello3.client.service.HelloServiceClientImpl;
import ro.ubb.hello3.client.tcp.TcpClient;
import ro.ubb.hello3.client.ui.ClientConsole;
import ro.ubb.hello3.common.HelloService;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * author: radu
 */
public class ClientApp {
    public static void main(String[] args) {
        ExecutorService executorService =
                Executors.newFixedThreadPool(
                        Runtime.getRuntime().availableProcessors());
        TcpClient tcpClient = new TcpClient(HelloService.SERVER_HOST,
                                            HelloService.SERVER_PORT);
        HelloService helloService =
                new HelloServiceClientImpl(executorService, tcpClient);
        ClientConsole clientConsole = new ClientConsole(helloService);

        clientConsole.runConsole();

        executorService.shutdownNow();

        System.out.println("client - bye");
    }
}

package ro.ubb.hello3.client.tcp;

import ro.ubb.hello3.common.HelloServiceException;
import ro.ubb.hello3.common.Message;

import java.io.IOException;
import java.net.Socket;

/**
 * author: radu
 */
public class TcpClient {
    private String host;
    private int port;

    public TcpClient(String host, int port) {
        this.host = host;
        this.port = port;
    }

    public Message sendAndReceive(Message request) {
        try (var socket = new Socket(host, port);
             var is = socket.getInputStream();
             var os = socket.getOutputStream()) {

            request.writeTo(os);
            System.out.println("client - sent request: " + request);

            Message response = new Message();
            response.readFrom(is);
            System.out.println("client - received response: " + response);

            return response;

        } catch (IOException e) {
            e.printStackTrace();
            throw new HelloServiceException("client - exception connecting to" +
                                            " server", e);
        }
    }
}

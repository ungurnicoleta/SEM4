package ro.ubb.hello3.common;

/**
 * author: radu
 */
public class HelloServiceException extends RuntimeException {
    public HelloServiceException(String message) {
        super(message);
    }

    public HelloServiceException(String message, Throwable cause) {
        super(message, cause);
    }

    public HelloServiceException(Throwable cause) {
        super(cause);
    }
}

package ro.ubb.catalog.core.repository;

import ro.ubb.catalog.core.model.Discipline;

/**
 * author: radu
 */
public interface DisciplineRepository
        extends CatalogRepository<Discipline, Long> {
}

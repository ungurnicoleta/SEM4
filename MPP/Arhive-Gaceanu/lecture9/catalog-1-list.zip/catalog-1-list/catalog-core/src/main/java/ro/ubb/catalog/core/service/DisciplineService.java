package ro.ubb.catalog.core.service;

import ro.ubb.catalog.core.model.Discipline;

import java.util.List;

/**
 * author: radu
 */
public interface DisciplineService {
    List<Discipline> getAllDisciplines();
}

export class Discipline {
  id: number;
  title: string;
}
